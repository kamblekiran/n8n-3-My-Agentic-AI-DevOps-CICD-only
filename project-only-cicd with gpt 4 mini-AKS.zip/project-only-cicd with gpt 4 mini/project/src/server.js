const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const dotenv = require('dotenv');
const winston = require('winston');

// Load environment variables
dotenv.config();

// Import route handlers
const agentRoutes = require('./routes/agents');
const notificationRoutes = require('./routes/notifications');
const healthRoutes = require('./routes/health');

// Import middleware
const authMiddleware = require('./middleware/auth');
const errorHandler = require('./middleware/errorHandler');

// Configure logger - simplified for POC
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.simple()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' }),
    new winston.transports.Console()
  ]
});

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:5678'],
  credentials: true
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Request logging
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path}`, {
    ip: req.ip,
    userAgent: req.get('User-Agent')
  });
  next();
});

// Authentication middleware for protected routes
app.use('/agent', authMiddleware);

// Routes
app.use('/health', healthRoutes);
app.use('/agent', agentRoutes);
app.use('/notifications', notificationRoutes);

// Provision AKS cluster - new endpoint
app.post('/agent/provision-aks', async (req, res) => {
  try {
    const params = req.body;
    
    // Extract parameters
    const { repository, environment = 'staging', node_count = 1, vm_size = 'Standard_D2s_v3', wait_for_ready = true } = params;
    
    // Validate required parameters
    if (!repository) {
      return res.status(400).json({
        error: 'Missing required parameter',
        message: 'Repository parameter is required'
      });
    }
    
    // Parse repository
    const [owner, repo] = repository.split('/');
    
    if (!owner || !repo) {
      return res.status(400).json({
        error: 'Invalid repository format',
        message: 'Repository must be in format owner/repo'
      });
    }
    
    // Create a valid cluster name based on environment and repo
    const clusterName = `${environment}-${repo.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
    
    // For debugging
    logger.debug('Provision AKS request params:', { 
      repository: params.repository, 
      environment: environment,
      node_count: node_count,
      vm_size: vm_size,
      wait_for_ready: wait_for_ready,
      cluster_name: clusterName
    });
    
    // Provision the AKS cluster
    const aksResult = await provisionAKS(params);
    
    res.json(aksResult);
  } catch (err) {
    logger.error('Provisioning AKS cluster failed:', err);
    res.status(500).json({
      error: 'Provisioning failed',
      message: err.message
    });
  }
});

// Update your existing /agent/deploy endpoint
app.post('/agent/deploy', async (req, res) => {
  try {
    const params = req.body;
    
    // Extract cluster information
    const { repository, image, environment = 'staging', k8s_manifests, cluster_name } = params;
    
    // For debugging
    logger.debug('Deploy agent request params:', { 
      repository: params.repository, 
      image: params.image,
      environment: environment,
      cluster_name: cluster_name,
      has_k8s_manifests: !!params.k8s_manifests,
      manifest_keys: params.k8s_manifests ? Object.keys(params.k8s_manifests) : []
    });
    
    // Validate required parameters
    if (!repository) {
      return res.status(400).json({
        error: 'Missing required parameter',
        message: 'Repository parameter is required'
      });
    }
    
    // Use the passed cluster name or generate one
    const [owner, repo] = repository.split('/');
    const actualClusterName = cluster_name || `${environment}-${repo.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
    
    // Skip cluster creation since it was done in previous step
    params.create_cluster = false;
    params.existing_cluster = actualClusterName;
    
    const result = await deployAgent.deploy(params);
    
    res.json(result);
  } catch (err) {
    logger.error('Deployment failed:', err);
    res.status(500).json({
      error: 'Deployment failed',
      message: err.message
    });
  }
});

// Error handling middleware
app.use(errorHandler);

// Start the server
app.listen(PORT, () => {
  logger.info(`Server is running on port ${PORT}`);
});

module.exports = app;