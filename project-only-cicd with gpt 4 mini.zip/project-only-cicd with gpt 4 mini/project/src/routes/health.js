const express = require('express');
const router = express.Router();

// Simple health check endpoint for POC
router.get('/', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: '1.0.0'
  });
});

// Simplified readiness check
router.get('/ready', (req, res) => {
  // Simple checks for essential services
  const checks = {
    server: 'ready',
    api_services: process.env.OPENAI_API_KEY ? 'ready' : 'not_configured'
  };

  res.status(200).json({
    status: 'ready',
    checks,
    timestamp: new Date().toISOString()
  });
});

module.exports = router;