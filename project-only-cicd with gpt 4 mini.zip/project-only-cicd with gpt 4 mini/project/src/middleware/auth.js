const jwt = require('jsonwebtoken');
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.simple(),
  transports: [new winston.transports.Console()]
});

const authMiddleware = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      return res.status(401).json({
        error: 'Unauthorized',
        message: 'Authorization header required'
      });
    }

    const token = authHeader.split(' ')[1]; // Bearer <token>
    
    if (!token) {
      return res.status(401).json({
        error: 'Unauthorized',
        message: 'Token required'
      });
    }

    // For POC, accept a simple token comparison
    if (token === process.env.MCP_SERVER_TOKEN) {
      req.user = { id: 'system', role: 'admin' };
      return next();
    }
    
    // Fallback to JWT if token doesn't match simple token
    try {
      const secret = process.env.JWT_SECRET || 'poc-secret-key';
      const decoded = jwt.verify(token, secret);
      req.user = decoded;
      next();
    } catch (jwtError) {
      throw new Error('Invalid token');
    }
  } catch (error) {
    logger.error('Authentication failed:', error);
    res.status(401).json({
      error: 'Unauthorized',
      message: 'Invalid token'
    });
  }
};

module.exports = authMiddleware;