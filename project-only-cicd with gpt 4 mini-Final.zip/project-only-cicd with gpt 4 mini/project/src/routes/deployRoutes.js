router.post('/deploy', async (req, res) => {
  try {
    const { repository, image } = req.body;
    
    if (!repository || !image) {
      return res.status(400).json({ error: 'Repository and image are required' });
    }
    
    const deployAgent = new DeployAgent();
    const result = await deployAgent.deploy(req.body);
    
    res.json(result);
  } catch (error) {
    console.error('Deployment error:', error);
    res.status(500).json({ error: error.message });
  }
});